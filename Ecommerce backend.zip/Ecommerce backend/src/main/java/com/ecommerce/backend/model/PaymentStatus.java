package com.ecommerce.backend.model;

public enum PaymentStatus {
    PENDING,
    PAID,
    FAILED
}
