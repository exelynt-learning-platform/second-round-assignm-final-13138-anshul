package com.ecommerce.backend.controller;

import com.ecommerce.backend.dto.CreateOrderRequest;
import com.ecommerce.backend.dto.OrderResponse;
import com.ecommerce.backend.model.CustomerOrder;
import com.ecommerce.backend.model.PaymentStatus;
import com.ecommerce.backend.service.OrderService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/orders")
public class OrderController {
    private final OrderService orderService;

    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    @PostMapping("/create")
    public ResponseEntity<OrderResponse> create(Authentication authentication, @Valid @RequestBody CreateOrderRequest request) {
        CustomerOrder order = orderService.createFromCart(authentication.getName(), request);
        OrderResponse response = convertToOrderResponse(order);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @PostMapping
    public ResponseEntity<OrderResponse> createDirect(Authentication authentication, @Valid @RequestBody CreateOrderRequest request) {
        CustomerOrder order = orderService.createFromCart(authentication.getName(), request);
        OrderResponse response = convertToOrderResponse(order);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    @GetMapping
    public ResponseEntity<List<OrderResponse>> getAll(Authentication authentication) {
        List<CustomerOrder> orders = orderService.getUserOrders(authentication.getName());
        List<OrderResponse> responses = orders.stream()
                .map(this::convertToOrderResponse)
                .toList();
        return ResponseEntity.ok(responses);
    }

    @GetMapping("/{orderId}")
    public ResponseEntity<OrderResponse> getById(Authentication authentication, @PathVariable Long orderId) {
        CustomerOrder order = orderService.getUserOrderById(authentication.getName(), orderId);
        OrderResponse response = convertToOrderResponse(order);
        return ResponseEntity.ok(response);
    }

    private OrderResponse convertToOrderResponse(CustomerOrder order) {
        return new OrderResponse(
                order.getId(),
                order.getTotalPrice(),
                order.getShippingDetails(),
                order.getPaymentStatus(),
                order.getPaymentReference(),
                order.getCreatedAt(),
                order.getItems().stream()
                        .map(item -> new com.ecommerce.backend.dto.OrderItemResponse(
                                item.getId(),
                                new com.ecommerce.backend.dto.ProductResponse(
                                        item.getProduct().getId(),
                                        item.getProduct().getName(),
                                        item.getProduct().getDescription(),
                                        item.getProduct().getPrice(),
                                        item.getProduct().getStockQuantity(),
                                        item.getProduct().getImageUrl()
                                ),
                                item.getQuantity(),
                                item.getUnitPrice()
                        ))
                        .toList()
        );
    }
}
