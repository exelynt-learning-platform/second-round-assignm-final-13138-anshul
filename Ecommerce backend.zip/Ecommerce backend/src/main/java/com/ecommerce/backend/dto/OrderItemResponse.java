package com.ecommerce.backend.dto;

import java.math.BigDecimal;

public record OrderItemResponse(
    Long id,
    ProductResponse product,
    Integer quantity,
    BigDecimal unitPrice
) {}
