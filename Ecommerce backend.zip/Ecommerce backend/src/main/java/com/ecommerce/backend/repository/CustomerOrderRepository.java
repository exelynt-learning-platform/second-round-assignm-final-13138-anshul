package com.ecommerce.backend.repository;

import com.ecommerce.backend.model.CustomerOrder;
import com.ecommerce.backend.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CustomerOrderRepository extends JpaRepository<CustomerOrder, Long> {
    List<CustomerOrder> findByUser(User user);
    Optional<CustomerOrder> findByPaymentReference(String paymentReference);
}
