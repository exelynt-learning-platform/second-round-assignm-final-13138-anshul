package com.ecommerce.backend.dto;

import jakarta.validation.constraints.NotNull;

public record PaymentRequest(@NotNull Long orderId) {}
