package com.ecommerce.backend.service;

import com.ecommerce.backend.dto.CartItemRequest;
import com.ecommerce.backend.exception.BadRequestException;
import com.ecommerce.backend.exception.NotFoundException;
import com.ecommerce.backend.model.CartItem;
import com.ecommerce.backend.model.Product;
import com.ecommerce.backend.model.User;
import com.ecommerce.backend.repository.CartItemRepository;
import com.ecommerce.backend.repository.ProductRepository;
import com.ecommerce.backend.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartService {
    private final CartItemRepository cartItemRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    public CartService(CartItemRepository cartItemRepository, ProductRepository productRepository, UserRepository userRepository) {
        this.cartItemRepository = cartItemRepository;
        this.productRepository = productRepository;
        this.userRepository = userRepository;
    }

    public List<CartItem> getCart(String email) {
        User user = getUser(email);
        return cartItemRepository.findByUser(user);
    }

    public CartItem addOrUpdate(String email, CartItemRequest request) {
        User user = getUser(email);
        Product product = productRepository.findById(request.productId())
                .orElseThrow(() -> new NotFoundException("Product not found"));

        if (request.quantity() > product.getStockQuantity()) {
            throw new BadRequestException("Requested quantity exceeds stock");
        }

        CartItem item = cartItemRepository.findByUserAndProduct(user, product).orElseGet(() -> {
            CartItem cartItem = new CartItem();
            cartItem.setUser(user);
            cartItem.setProduct(product);
            return cartItem;
        });
        item.setQuantity(request.quantity());
        return cartItemRepository.save(item);
    }

    public void remove(String email, Long productId) {
        User user = getUser(email);
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new NotFoundException("Product not found"));
        CartItem item = cartItemRepository.findByUserAndProduct(user, product)
                .orElseThrow(() -> new NotFoundException("Item not in cart"));
        cartItemRepository.delete(item);
    }

    public void clear(User user) {
        cartItemRepository.deleteAll(cartItemRepository.findByUser(user));
    }

    User getUser(String email) {
        return userRepository.findByEmail(email).orElseThrow(() -> new NotFoundException("User not found"));
    }
}
