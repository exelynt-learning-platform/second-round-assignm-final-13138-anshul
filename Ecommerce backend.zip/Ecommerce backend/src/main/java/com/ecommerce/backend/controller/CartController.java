package com.ecommerce.backend.controller;

import com.ecommerce.backend.dto.CartItemRequest;
import com.ecommerce.backend.dto.CartResponse;
import com.ecommerce.backend.model.CartItem;
import com.ecommerce.backend.service.CartService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cart")
public class CartController {
    private final CartService cartService;

    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    @GetMapping
    public ResponseEntity<List<CartResponse>> getCart(Authentication authentication) {
        List<CartItem> items = cartService.getCart(authentication.getName());
        List<CartResponse> responses = items.stream()
                .map(this::convertToCartResponse)
                .toList();
        return ResponseEntity.ok(responses);
    }

    @PostMapping("/add")
    public ResponseEntity<CartResponse> addToCart(Authentication authentication, @Valid @RequestBody CartItemRequest request) {
        CartItem item = cartService.addOrUpdate(authentication.getName(), request);
        return ResponseEntity.ok(convertToCartResponse(item));
    }

    @PutMapping("/update")
    public ResponseEntity<CartResponse> updateCartItem(Authentication authentication, @Valid @RequestBody CartItemRequest request) {
        CartItem item = cartService.addOrUpdate(authentication.getName(), request);
        return ResponseEntity.ok(convertToCartResponse(item));
    }

    @DeleteMapping("/{productId}")
    public ResponseEntity<Void> remove(Authentication authentication, @PathVariable Long productId) {
        cartService.remove(authentication.getName(), productId);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/clear")
    public ResponseEntity<Void> clearCart(Authentication authentication) {
        cartService.clear(authentication.getName());
        return ResponseEntity.noContent().build();
    }

    private CartResponse convertToCartResponse(CartItem item) {
        return new CartResponse(
                item.getId(),
                new com.ecommerce.backend.dto.ProductResponse(
                        item.getProduct().getId(),
                        item.getProduct().getName(),
                        item.getProduct().getDescription(),
                        item.getProduct().getPrice(),
                        item.getProduct().getStockQuantity(),
                        item.getProduct().getImageUrl()
                ),
                item.getQuantity(),
                item.getProduct().getPrice().multiply(java.math.BigDecimal.valueOf(item.getQuantity()))
        );
    }
}
