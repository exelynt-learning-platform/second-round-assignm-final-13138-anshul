package com.ecommerce.backend.dto;

public enum PaymentStatus {
    PENDING,
    PAID,
    FAILED,
    REFUNDED
}
