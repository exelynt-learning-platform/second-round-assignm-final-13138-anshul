package com.ecommerce.backend.dto;

import java.math.BigDecimal;

public record CartResponse(
    Long id,
    ProductResponse product,
    Integer quantity,
    BigDecimal totalPrice
) {}
