package com.ecommerce.backend.dto;

import jakarta.validation.constraints.NotBlank;

public record CreateOrderRequest(@NotBlank String shippingDetails) {}
