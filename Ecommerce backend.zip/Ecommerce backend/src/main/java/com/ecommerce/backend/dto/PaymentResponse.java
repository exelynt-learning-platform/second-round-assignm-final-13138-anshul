package com.ecommerce.backend.dto;

public record PaymentResponse(String checkoutUrl, String sessionId) {}
