package com.ecommerce.backend.service;

import com.ecommerce.backend.dto.CreateOrderRequest;
import com.ecommerce.backend.exception.BadRequestException;
import com.ecommerce.backend.exception.NotFoundException;
import com.ecommerce.backend.model.*;
import com.ecommerce.backend.repository.CartItemRepository;
import com.ecommerce.backend.repository.CustomerOrderRepository;
import com.ecommerce.backend.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
public class OrderService {
    private final CustomerOrderRepository orderRepository;
    private final UserRepository userRepository;
    private final CartItemRepository cartItemRepository;

    public OrderService(CustomerOrderRepository orderRepository, UserRepository userRepository, CartItemRepository cartItemRepository) {
        this.orderRepository = orderRepository;
        this.userRepository = userRepository;
        this.cartItemRepository = cartItemRepository;
    }

    @Transactional
    public CustomerOrder createFromCart(String email, CreateOrderRequest request) {
        User user = userRepository.findByEmail(email).orElseThrow(() -> new NotFoundException("User not found"));
        List<CartItem> cart = cartItemRepository.findByUser(user);
        if (cart.isEmpty()) {
            throw new BadRequestException("Cart is empty");
        }

        CustomerOrder order = new CustomerOrder();
        order.setUser(user);
        order.setShippingDetails(request.shippingDetails());

        BigDecimal total = BigDecimal.ZERO;
        for (CartItem c : cart) {
            Product product = c.getProduct();
            if (c.getQuantity() > product.getStockQuantity()) {
                throw new BadRequestException("Insufficient stock for " + product.getName());
            }
            product.setStockQuantity(product.getStockQuantity() - c.getQuantity());

            OrderItem item = new OrderItem();
            item.setOrder(order);
            item.setProduct(product);
            item.setQuantity(c.getQuantity());
            item.setUnitPrice(product.getPrice());
            order.getItems().add(item);
            total = total.add(product.getPrice().multiply(BigDecimal.valueOf(c.getQuantity())));
        }

        order.setTotalPrice(total);
        CustomerOrder saved = orderRepository.save(order);
        cartItemRepository.deleteAll(cart);
        return saved;
    }

    public List<CustomerOrder> getUserOrders(String email) {
        User user = userRepository.findByEmail(email).orElseThrow(() -> new NotFoundException("User not found"));
        return orderRepository.findByUser(user);
    }

    public CustomerOrder getUserOrderById(String email, Long orderId) {
        User user = userRepository.findByEmail(email).orElseThrow(() -> new NotFoundException("User not found"));
        CustomerOrder order = orderRepository.findById(orderId).orElseThrow(() -> new NotFoundException("Order not found"));
        if (!order.getUser().getId().equals(user.getId())) {
            throw new BadRequestException("You can only view your own order");
        }
        return order;
    }

    public CustomerOrder save(CustomerOrder order) {
        return orderRepository.save(order);
    }
}
