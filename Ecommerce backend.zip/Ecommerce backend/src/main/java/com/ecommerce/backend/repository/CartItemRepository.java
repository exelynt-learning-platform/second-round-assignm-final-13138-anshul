package com.ecommerce.backend.repository;

import com.ecommerce.backend.model.CartItem;
import com.ecommerce.backend.model.Product;
import com.ecommerce.backend.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface CartItemRepository extends JpaRepository<CartItem, Long> {
    List<CartItem> findByUser(User user);
    
    @Query("SELECT ci FROM CartItem ci WHERE ci.user = :user AND ci.product = :product")
    Optional<CartItem> findByUserAndProduct(@Param("user") User user, @Param("product") Product product);
    
    void deleteAllByUser(User user);
}
