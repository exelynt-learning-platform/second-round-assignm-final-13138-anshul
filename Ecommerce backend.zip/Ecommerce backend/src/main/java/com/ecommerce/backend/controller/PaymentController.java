package com.ecommerce.backend.controller;

import com.ecommerce.backend.dto.PaymentRequest;
import com.ecommerce.backend.dto.PaymentResponse;
import com.ecommerce.backend.service.PaymentService;
import com.razorpay.RazorpayException;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {
    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping("/checkout")
    public ResponseEntity<PaymentResponse> checkout(Authentication authentication, @Valid @RequestBody PaymentRequest request)
            throws RazorpayException {
        return ResponseEntity.ok(paymentService.createCheckoutSession(authentication.getName(), request.orderId()));
    }

    @PostMapping("/verify")
    public ResponseEntity<Boolean> verifyPayment(
            @RequestParam String orderId, 
            @RequestParam String paymentId, 
            @RequestParam String signature) {
        boolean isValid = paymentService.verifyPayment(orderId, paymentId, signature);
        return ResponseEntity.ok(isValid);
    }

    @PostMapping("/success")
    public ResponseEntity<Void> paymentSuccess(@RequestParam Long orderId) {
        paymentService.markPaid(orderId);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/failed")
    public ResponseEntity<Void> paymentFailed(@RequestParam Long orderId) {
        paymentService.markFailed(orderId);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/webhook")
    public ResponseEntity<Void> handleRazorpayWebhook(@RequestBody String payload) {
        paymentService.handleWebhookEvent(payload);
        return ResponseEntity.ok().build();
    }
}
