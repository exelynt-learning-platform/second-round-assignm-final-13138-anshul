package com.ecommerce.backend.service;

import com.ecommerce.backend.dto.PaymentResponse;
import com.ecommerce.backend.exception.BadRequestException;
import com.ecommerce.backend.exception.NotFoundException;
import com.ecommerce.backend.model.CustomerOrder;
import com.ecommerce.backend.model.PaymentStatus;
import com.ecommerce.backend.repository.CustomerOrderRepository;
import com.stripe.Stripe;
import com.stripe.exception.SignatureVerificationException;
import com.stripe.exception.StripeException;
import com.stripe.model.Event;
import com.stripe.net.Webhook;
import com.stripe.model.checkout.Session;
import com.stripe.param.checkout.SessionCreateParams;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class PaymentService {
    private final CustomerOrderRepository orderRepository;

    @Value("${app.payment.success-url}")
    private String successUrl;

    @Value("${app.payment.cancel-url}")
    private String cancelUrl;

    @Value("${app.stripe.webhook-secret}")
    private String webhookSecret;

    public PaymentService(CustomerOrderRepository orderRepository, @Value("${app.stripe.secret-key}") String stripeSecret) {
        this.orderRepository = orderRepository;
        Stripe.apiKey = stripeSecret;
    }

    public PaymentResponse createCheckoutSession(String email, Long orderId) throws StripeException {
        CustomerOrder order = orderRepository.findById(orderId)
                .orElseThrow(() -> new NotFoundException("Order not found"));

        if (!order.getUser().getEmail().equals(email)) {
            throw new BadRequestException("You can only pay for your own order");
        }

        if (order.getPaymentStatus() == PaymentStatus.PAID) {
            throw new BadRequestException("Order already paid");
        }

        long amountInCents = toCents(order.getTotalPrice());
        SessionCreateParams params = SessionCreateParams.builder()
                .setMode(SessionCreateParams.Mode.PAYMENT)
                .setSuccessUrl(successUrl + "?orderId=" + order.getId())
                .setCancelUrl(cancelUrl + "?orderId=" + order.getId())
                .addLineItem(SessionCreateParams.LineItem.builder()
                        .setQuantity(1L)
                        .setPriceData(SessionCreateParams.LineItem.PriceData.builder()
                                .setCurrency("usd")
                                .setUnitAmount(amountInCents)
                                .setProductData(SessionCreateParams.LineItem.PriceData.ProductData.builder()
                                        .setName("Order #" + order.getId())
                                        .build())
                                .build())
                        .build())
                .build();

        Session session = Session.create(params);
        order.setPaymentReference(session.getId());
        orderRepository.save(order);

        return new PaymentResponse(session.getUrl(), session.getId());
    }

    public void handleWebhookEvent(String payload, String signatureHeader) {
        try {
            Event event = Webhook.constructEvent(payload, signatureHeader, webhookSecret);
            if ("checkout.session.completed".equals(event.getType())) {
                updateOrderStatusBySession(event, PaymentStatus.PAID);
            } else if ("checkout.session.expired".equals(event.getType())) {
                updateOrderStatusBySession(event, PaymentStatus.FAILED);
            } else if ("checkout.session.async_payment_failed".equals(event.getType())) {
                updateOrderStatusBySession(event, PaymentStatus.FAILED);
            }
        } catch (SignatureVerificationException e) {
            throw new BadRequestException("Invalid Stripe webhook signature");
        }
    }

    public void markPaid(Long orderId) {
        CustomerOrder order = orderRepository.findById(orderId)
                .orElseThrow(() -> new NotFoundException("Order not found"));
        order.setPaymentStatus(PaymentStatus.PAID);
        orderRepository.save(order);
    }

    public void markFailed(Long orderId) {
        CustomerOrder order = orderRepository.findById(orderId)
                .orElseThrow(() -> new NotFoundException("Order not found"));
        order.setPaymentStatus(PaymentStatus.FAILED);
        orderRepository.save(order);
    }

    private long toCents(BigDecimal value) {
        return value.multiply(BigDecimal.valueOf(100)).longValue();
    }

    private void updateOrderStatusBySession(Event event, PaymentStatus status) {
        if (event.getData() == null || event.getData().getObject() == null) {
            return;
        }
        Session session = (Session) event.getDataObjectDeserializer()
                .getObject()
                .orElse(null);
        if (session == null || session.getId() == null) {
            return;
        }

        orderRepository.findByPaymentReference(session.getId())
                .ifPresent(order -> {
                    order.setPaymentStatus(status);
                    orderRepository.save(order);
                });
    }
}
