package com.ecommerce.backend.service;

import com.ecommerce.backend.dto.PaymentResponse;
import com.ecommerce.backend.exception.BadRequestException;
import com.ecommerce.backend.exception.NotFoundException;
import com.ecommerce.backend.model.CustomerOrder;
import com.ecommerce.backend.model.PaymentStatus;
import com.ecommerce.backend.repository.CustomerOrderRepository;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import com.razorpay.Utils;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class PaymentService {
    private final CustomerOrderRepository orderRepository;
    private final RazorpayClient razorpayClient;

    @Value("${app.payment.success-url}")
    private String successUrl;

    @Value("${app.payment.cancel-url}")
    private String cancelUrl;

    @Value("${app.razorpay.key-secret}")
    private String razorpayKeySecret;

    public PaymentService(CustomerOrderRepository orderRepository,
                         @Value("${app.razorpay.key-id}") String keyId,
                         @Value("${app.razorpay.key-secret}") String keySecret) throws RazorpayException {
        this.orderRepository = orderRepository;
        this.razorpayClient = new RazorpayClient(keyId, keySecret);
        this.razorpayKeySecret = keySecret;
    }

    public PaymentResponse createCheckoutSession(String email, Long orderId) throws RazorpayException {
        CustomerOrder order = orderRepository.findById(orderId)
                .orElseThrow(() -> new NotFoundException("Order not found"));

        if (!order.getUser().getEmail().equals(email)) {
            throw new BadRequestException("You can only pay for your own order");
        }

        if (order.getPaymentStatus() == PaymentStatus.PAID) {
            throw new BadRequestException("Order already paid");
        }

        try {
            JSONObject orderRequest = new JSONObject();
            orderRequest.put("amount", toPaise(order.getTotalPrice()));
            orderRequest.put("currency", "INR");
            orderRequest.put("receipt", "order_" + order.getId());
            orderRequest.put("payment_capture", 1);

            Order razorpayOrder = razorpayClient.orders.create(orderRequest);
            
            order.setPaymentReference(razorpayOrder.get("id"));
            orderRepository.save(order);

            return new PaymentResponse(null, razorpayOrder.get("id"));
        } catch (RazorpayException e) {
            throw new BadRequestException("Failed to create Razorpay order: " + e.getMessage());
        }
    }

    public boolean verifyPayment(String orderId, String paymentId, String signature) {
        try {
            JSONObject attributes = new JSONObject();
            attributes.put("razorpay_order_id", orderId);
            attributes.put("razorpay_payment_id", paymentId);
            attributes.put("razorpay_signature", signature);

            // Use the injected key secret from configuration
            boolean isValid = Utils.verifyPaymentSignature(attributes, razorpayKeySecret);
            
            if (isValid) {
                markPaidByOrderId(orderId);
            } else {
                markFailedByOrderId(orderId);
            }
            
            return isValid;
        } catch (RazorpayException e) {
            throw new BadRequestException("Payment verification failed: " + e.getMessage());
        }
    }

    public void handleWebhookEvent(String payload) {
        try {
            // Razorpay webhook handling logic
            JSONObject webhookPayload = new JSONObject(payload);
            String event = webhookPayload.getString("event");
            
            if ("payment.captured".equals(event)) {
                JSONObject payment = webhookPayload.getJSONObject("payload").getJSONObject("payment").getJSONObject("entity");
                String orderId = payment.getString("order_id");
                markPaidByOrderId(orderId);
            } else if ("payment.failed".equals(event)) {
                JSONObject payment = webhookPayload.getJSONObject("payload").getJSONObject("payment").getJSONObject("entity");
                String orderId = payment.getString("order_id");
                markFailedByOrderId(orderId);
            }
        } catch (Exception e) {
            throw new BadRequestException("Invalid Razorpay webhook payload");
        }
    }

    public void markPaid(Long orderId) {
        CustomerOrder order = orderRepository.findById(orderId)
                .orElseThrow(() -> new NotFoundException("Order not found"));
        order.setPaymentStatus(PaymentStatus.PAID);
        orderRepository.save(order);
    }

    public void markFailed(Long orderId) {
        CustomerOrder order = orderRepository.findById(orderId)
                .orElseThrow(() -> new NotFoundException("Order not found"));
        order.setPaymentStatus(PaymentStatus.FAILED);
        orderRepository.save(order);
    }

    private void markPaidByOrderId(String razorpayOrderId) {
        orderRepository.findByPaymentReference(razorpayOrderId)
                .ifPresent(order -> {
                    order.setPaymentStatus(PaymentStatus.PAID);
                    orderRepository.save(order);
                });
    }

    private void markFailedByOrderId(String razorpayOrderId) {
        orderRepository.findByPaymentReference(razorpayOrderId)
                .ifPresent(order -> {
                    order.setPaymentStatus(PaymentStatus.FAILED);
                    orderRepository.save(order);
                });
    }

    private int toPaise(BigDecimal value) {
        return value.multiply(BigDecimal.valueOf(100)).intValue();
    }
}
