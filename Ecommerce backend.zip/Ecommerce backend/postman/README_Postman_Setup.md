# E-commerce Backend API - Postman Setup Guide

## 🚀 Quick Start

### 1. Import Collection & Environment

1. **Open Postman Desktop App**
2. **Import Collection**: 
   - Click `Import` → Select `Ecommerce_API_Postman_Collection.json`
   - Choose collection import option
3. **Import Environment**:
   - Click `Import` → Select `Ecommerce_API_Environment.json`
   - Choose environment import option
4. **Select Environment**: 
   - Click the environment dropdown (top-right)
   - Select "E-commerce API Environment"

### 2. API Base URL
- **Local**: `http://localhost:8080`
- **Production**: Update `baseUrl` variable in environment

### 3. Authentication Setup

#### Step 1: Register User
```
POST /api/auth/register
{
    "email": "user@example.com",
    "password": "password123"
}
```

#### Step 2: Login User
```
POST /api/auth/login
{
    "email": "user@example.com", 
    "password": "password123"
}
```

#### Step 3: Copy JWT Token
- From login response, copy the `token` value
- Update `jwtToken` environment variable with the token

## 📚 API Endpoints Overview

### 🔐 Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - User login

### 🛍️ Products
- `GET /api/products` - Get all products
- `GET /api/products/{id}` - Get product by ID
- `POST /api/products` - Create product (Admin)
- `PUT /api/products/{id}` - Update product (Admin)
- `DELETE /api/products/{id}` - Delete product (Admin)

### 🛒 Cart Management
- `GET /api/cart` - Get cart items
- `POST /api/cart/add` - Add item to cart
- `PUT /api/cart/update` - Update cart item quantity
- `DELETE /api/cart/remove/{productId}` - Remove item from cart
- `DELETE /api/cart/clear` - Clear entire cart

### 📦 Orders
- `GET /api/orders` - Get user orders
- `GET /api/orders/{id}` - Get order by ID
- `POST /api/orders/create` - Create new order

### 💳 Payments (Razorpay)
- `POST /api/payments/checkout` - Create Razorpay order
- `POST /api/payments/verify` - Verify payment signature
- `POST /api/payments/success` - Mark payment successful
- `POST /api/payments/failed` - Mark payment failed
- `POST /api/payments/webhook` - Razorpay webhook handler

## 🔧 Configuration Requirements

### Database Setup
1. **MySQL Server** running on localhost:3306
2. **Create Database**: `CREATE DATABASE ecomdb;`
3. **Update Credentials** in `application.properties` if needed

### Razorpay Setup
1. **Create Razorpay Account**: https://razorpay.com/
2. **Get Test Keys** from Razorpay Dashboard
3. **Update application.properties**:
   ```properties
   app.razorpay.key-id=rzp_test_your_key_id
   app.razorpay.key-secret=rzp_test_your_secret_key
   ```

## 🧪 Testing Flow

### Complete E-commerce Flow:
1. **Register/Login** → Get JWT token
2. **Create Products** (Admin) → Add inventory
3. **Browse Products** → View available items
4. **Add to Cart** → Build shopping cart
5. **Create Order** → Convert cart to order
6. **Process Payment** → Razorpay integration
7. **Verify Payment** → Complete transaction

### Payment Testing with Razorpay:
1. **Create Order** → Get Razorpay order ID
2. **Use Razorpay Test Mode** → Complete payment
3. **Verify Payment** → Confirm transaction
4. **Check Order Status** → Verify completion

## 📝 Sample Test Data

### Product Example:
```json
{
    "name": "Wireless Headphones",
    "description": "High-quality wireless headphones with noise cancellation",
    "price": 2999.99,
    "stockQuantity": 50,
    "imageUrl": "https://example.com/headphones.jpg"
}
```

### Order Example:
```json
{
    "shippingDetails": "123 Main St, Mumbai, Maharashtra 400001",
    "items": [
        {
            "productId": 1,
            "quantity": 2,
            "price": 2999.99
        }
    ]
}
```

## 🐛 Troubleshooting

### Common Issues:
1. **401 Unauthorized**: Check JWT token in `Authorization` header
2. **403 Forbidden**: Verify user role (admin endpoints)
3. **404 Not Found**: Ensure API base URL is correct
4. **500 Server Error**: Check database connection and logs

### Database Connection Issues:
- Verify MySQL is running
- Check database name `ecomdb`
- Confirm username/password in application.properties

### Razorpay Issues:
- Verify API keys are correct
- Use test mode for development
- Check webhook configuration

## 📞 Support

For issues:
1. Check Spring Boot application logs
2. Verify database and Razorpay configuration
3. Test endpoints individually before complex flows

## 🔄 Environment Variables

Update these in Postman environment:
- `baseUrl`: API server URL
- `jwtToken`: Authentication token (from login response)
- `userEmail`: Test user email
- `userPassword`: Test user password
