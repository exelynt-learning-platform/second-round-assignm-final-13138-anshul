# Ecommerce Backend API

## Run

```bash
mvn spring-boot:run
```

## Default Admin

- Email: `admin@shop.com`
- Password: `admin123`

## Auth

- `POST /api/auth/register`
- `POST /api/auth/login`

Use `Authorization: Bearer <token>` for protected endpoints.

## Main APIs

- Products: `GET /api/products`, `GET /api/products/{id}`
- Admin product CRUD: `POST/PUT/DELETE /api/products`
- Cart: `GET/POST/DELETE /api/cart`
- Orders: `POST /api/orders`, `GET /api/orders`, `GET /api/orders/{id}`
- Payments (Stripe): `POST /api/payments/checkout`

## Swagger/OpenAPI

- Swagger UI: `http://localhost:8080/swagger-ui.html`
- OpenAPI JSON: `http://localhost:8080/v3/api-docs`

## Postman Collection

- Import `postman/Ecommerce Backend API.postman_collection.json`
- Set collection variables:
  - `baseUrl` (default `http://localhost:8080`)
  - `jwtToken` (set after login)
  - `orderId`, `productId` (set from API responses)

## Notes

- Replace `app.stripe.secret-key` with your Stripe test key.
- Replace `app.stripe.webhook-secret` with your Stripe webhook endpoint secret.
- Payment success/failure handlers are exposed at:
  - `POST /api/payments/success?orderId=...`
  - `POST /api/payments/failed?orderId=...`
- Production-grade payment status update endpoint:
  - `POST /api/payments/webhook`
  - Header: `Stripe-Signature: <signature>`
